package mapp.com.sg.broadcastreceiver;

/**
 * Created by s38092 on 24/10/2016.
 */

public class NotifyMessage {
}
