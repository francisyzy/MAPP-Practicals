package mapp.com.sg.broadcastreceiver;

/**
 * Created by francisyzy on 16/08/2017.
 */

public class NotifyMessage {
}
